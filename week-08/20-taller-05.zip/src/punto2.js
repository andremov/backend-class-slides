/**
 * PUNTO 2
 * @param {*} req
 * @param {*} res
 */
export default async function punto2() {
  /*
   * Implementacion aqui
   */
}
