/**
 * PUNTO 1
 * @param {*} req
 * @param {*} res
 */
export default async function punto1(req, res) {
  /*
   * Implementacion aqui
   */
}
