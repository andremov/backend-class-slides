const datos = require("./datos.json");

function puntoUno(estudiantes) {
  // CODIGO DE PUNTO 1 AQUI
}

// CODIGO DE PUNTO 2 AQUI

// CODIGO DE PUNTO 3 AQUI
