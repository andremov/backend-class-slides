/**
 * PUNTO 3
 * @param {*} req
 * @param {*} res
 */
