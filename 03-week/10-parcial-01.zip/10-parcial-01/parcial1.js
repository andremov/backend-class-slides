const datos = require("./datos.json");

/*
  Para correr este archivo, utilicen el comando
  $ node parcial1.js

  Para abrir el terminal desde la ubicacion de este folder, usen Ctrl + Shift + C.

  La variable importada "datos" contiene datos de estudiantes.
*/

function puntoUno(estudiantes) {
  // CODIGO DE PUNTO 1 AQUI

  return 0;
}

function puntoDos(estudiantes) {
  // CODIGO DE PUNTO 2 AQUI

  return [];
}

function puntoTres(estudiantes) {
  // CODIGO DE PUNTO 3 AQUI

  return [];
}

function puntoCuatro(numeros) {
  // CODIGO DE PUNTO 4 AQUI

  return 0;
}

function puntoCinco(palabra) {
  // CODIGO DE PUNTO 5 AQUI

  return false;
}

function puntoSeis(palabra) {
  // CODIGO DE PUNTO 6 AQUI

  return "";
}

// CODIGO DE PUNTO 7 AQUI
