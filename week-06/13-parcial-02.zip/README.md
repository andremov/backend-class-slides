# Parcial #2

> ## Instrucciones:
>
> - Leer detenidamente cada punto, desarrollar en el orden deseado.
> - Utilizar el archivo parcial2.js, renombrar el archivo a [codigo de estudiante].js.
> - No renombrar las funciones de los puntos.
> - El codigo por fuera de las funciones de los puntos es valido, pueden desarrollar funciones auxiliares.
> - Solo se envía el archivo parcial2.js.

## Puntos

1. Implemente una funcion que reciba los datos de estudiantes y retorne la informacion personal de los estudiantes "estrella" (promedio mayor a 2.5 y menor a 3.0).

2. Su compañero de trabajo, Julian, desarrolló el punto dos. Utilizando los conceptos aprendidos en JS Avanzado, mejore la función.

3. Desarrolle una funcion que reciba los datos de estudiantes y retorne los estudiantes que cumplan con los filtros y los datos "arreglados".

- FIX: Juntar nombres en campo "name".
- FIX: No incluir actividades extra curriculares.
- FIX: Solo incluir clases del semestre mas reciente.
- FILTER: Usuarios menores a 20 años
- FIX: Adicionar campo "title" segun genero (Sr. o Sra.)
- FIX: Sacar la informacion personal de su campo.

4. Mejore el punto cuatro utilizando los conceptos aprendidos en JS Avanzado.
